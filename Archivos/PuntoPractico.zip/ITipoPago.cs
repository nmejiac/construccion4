namespace PuntoParcial.Clases;

interface ITipoDePago{
    void TipoDePago(double monto);
}