namespace Clase14082023_POO_Herencia.clases;

interface ICuenta{
    void retirar(int monto);
}