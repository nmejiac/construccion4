namespace Clase14082023_POO_Herencia.clases;

public class Cuenta : ACuenta
{
    public Cuenta(int saldo)
    {
        this.saldo = saldo;
    }
}